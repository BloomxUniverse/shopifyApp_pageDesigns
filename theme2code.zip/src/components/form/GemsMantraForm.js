import React from 'react'
import FormDesign1 from './FormDesign1'

export default function GemsMantraForm() {
  return (
    <>
      <FormDesign1/>
    </>
  )
}
