import React from 'react';
import ResultTheme1 from './ResultTheme1';
export default function Result() {
  return (
    <>
      <ResultTheme1/>
    </>
  )
}
